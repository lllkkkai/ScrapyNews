from scrapy.cmdline import execute
execute(['scrapy', 'crawl', 'cnr_all_summary'])